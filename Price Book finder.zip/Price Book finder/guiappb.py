import re
import sys
import sqlite3
from PyQt5.QtWidgets import (
    QApplication, QWidget, QLabel, QLineEdit, QPushButton, QVBoxLayout, QMessageBox, QDesktopWidget
)
from PyQt5.QtGui import QFont, QPalette, QColor
from PyQt5.QtCore import Qt
from datetime import datetime, timedelta

class BookPriceFinder(QWidget):
    def __init__(self):
        super().__init__()

        # Window title, icon, and size
        self.setWindowTitle("Book Price Finder with Payment and Delivery Date")
        
        # Get screen size and set window size
        screen = QDesktopWidget().screenGeometry()
        width, height = screen.width(), screen.height()
        self.setGeometry(int(width * 0.2), int(height * 0.2), int(width * 0.6), int(height * 0.6))
        
        # Set background color and rounded corners for main window
        self.setStyleSheet("""
            background-color: #f5f7fa;
            border-radius: 10px;
            font-family: Arial;
        """)
        
        # Layout
        layout = QVBoxLayout()
        layout.setSpacing(15)
        layout.setContentsMargins(40, 40, 40, 40)
        
        # Title styling
        self.titleLabel = QLabel("Book Title:")
        self.titleLabel.setFont(QFont("Verdana", 14))
        self.titleLabel.setStyleSheet("color: #333;")
        self.titleInput = QLineEdit(self)
        self.titleInput.setFont(QFont("Verdana", 14))
        self.titleInput.setStyleSheet("border: 1px solid #aaa; padding: 8px; border-radius: 5px;")
        
        # Price output styling
        self.priceLabel = QLabel("Price (₹):")
        self.priceLabel.setFont(QFont("Verdana", 14))
        self.priceLabel.setStyleSheet("color: #333;")
        self.priceOutput = QLineEdit(self)
        self.priceOutput.setFont(QFont("Verdana", 14))
        self.priceOutput.setReadOnly(True)
        self.priceOutput.setStyleSheet("border: 1px solid #ddd; padding: 8px; background-color: #f9f9f9; border-radius: 5px;")
        
        # Quantity styling
        self.quantityLabel = QLabel("Quantity:")
        self.quantityLabel.setFont(QFont("Verdana", 14))
        self.quantityLabel.setStyleSheet("color: #333;")
        self.quantityInput = QLineEdit(self)
        self.quantityInput.setFont(QFont("Verdana", 14))
        self.quantityInput.setPlaceholderText("Enter quantity")
        self.quantityInput.setStyleSheet("border: 1px solid #aaa; padding: 8px; border-radius: 5px;")
        
        # Total amount output styling
        self.totalAmountLabel = QLabel("Total Amount (₹):")
        self.totalAmountLabel.setFont(QFont("Verdana", 14))
        self.totalAmountLabel.setStyleSheet("color: #333;")
        self.totalAmountOutput = QLineEdit(self)
        self.totalAmountOutput.setFont(QFont("Verdana", 14))
        self.totalAmountOutput.setReadOnly(True)
        self.totalAmountOutput.setStyleSheet("border: 1px solid #ddd; padding: 8px; background-color: #f9f9f9; border-radius: 5px;")
        
        # Payment styling
        self.paymentLabel = QLabel("Payment (₹):")
        self.paymentLabel.setFont(QFont("Verdana", 14))
        self.paymentLabel.setStyleSheet("color: #333;")
        self.paymentInput = QLineEdit(self)
        self.paymentInput.setFont(QFont("Verdana", 14))
        self.paymentInput.setPlaceholderText("Enter payment amount")
        self.paymentInput.setStyleSheet("border: 1px solid #aaa; padding: 8px; border-radius: 5px;")
        
        # Balance output styling
        self.balanceLabel = QLabel("Remaining Balance (₹):")
        self.balanceLabel.setFont(QFont("Verdana", 14))
        self.balanceLabel.setStyleSheet("color: #333;")
        self.balanceOutput = QLineEdit(self)
        self.balanceOutput.setFont(QFont("Verdana", 14))
        self.balanceOutput.setReadOnly(True)
        self.balanceOutput.setStyleSheet("border: 1px solid #ddd; padding: 8px; background-color: #f9f9f9; border-radius: 5px;")
        
        # Delivery date output styling
        self.deliveryDateLabel = QLabel("Expected Delivery Date:")
        self.deliveryDateLabel.setFont(QFont("Verdana", 14))
        self.deliveryDateLabel.setStyleSheet("color: #333;")
        self.deliveryDateOutput = QLineEdit(self)
        self.deliveryDateOutput.setFont(QFont("Verdana", 14))
        self.deliveryDateOutput.setReadOnly(True)
        self.deliveryDateOutput.setStyleSheet("border: 1px solid #ddd; padding: 8px; background-color: #f9f9f9; border-radius: 5px;")
        
        # Buttons with enhanced styles
        button_style = """
            font-size: 14px; padding: 10px; border-radius: 8px; color: white; 
            font-weight: bold; min-height: 40px; cursor: pointer;
        """
        
        self.findPriceButton = QPushButton("Find Price", self)
        self.findPriceButton.setFont(QFont("Verdana", 14))
        self.findPriceButton.setStyleSheet(f"background-color: #4CAF50; {button_style}")
        
        self.findTotalButton = QPushButton("Find Total Amount", self)
        self.findTotalButton.setFont(QFont("Verdana", 14))
        self.findTotalButton.setStyleSheet(f"background-color: #2196F3; {button_style}")
        
        self.calculateBalanceButton = QPushButton("Calculate Balance", self)
        self.calculateBalanceButton.setFont(QFont("Verdana", 14))
        self.calculateBalanceButton.setStyleSheet(f"background-color: #FF5722; {button_style}")
        
        self.calculateDeliveryDateButton = QPushButton("Calculate Delivery Date", self)
        self.calculateDeliveryDateButton.setFont(QFont("Verdana", 14))
        self.calculateDeliveryDateButton.setStyleSheet(f"background-color: #9C27B0; {button_style}")
        
        # Adding widgets to layout
        layout.addWidget(self.titleLabel)
        layout.addWidget(self.titleInput)
        layout.addWidget(self.priceLabel)
        layout.addWidget(self.priceOutput)
        layout.addWidget(self.quantityLabel)
        layout.addWidget(self.quantityInput)
        layout.addWidget(self.totalAmountLabel)
        layout.addWidget(self.totalAmountOutput)
        layout.addWidget(self.paymentLabel)
        layout.addWidget(self.paymentInput)
        layout.addWidget(self.balanceLabel)
        layout.addWidget(self.balanceOutput)
        layout.addWidget(self.deliveryDateLabel)
        layout.addWidget(self.deliveryDateOutput)
        layout.addWidget(self.findPriceButton)
        layout.addWidget(self.findTotalButton)
        layout.addWidget(self.calculateBalanceButton)
        layout.addWidget(self.calculateDeliveryDateButton)
        
        # Setting layout
        self.setLayout(layout)
        
        # Connecting buttons to functions
        self.findPriceButton.clicked.connect(self.find_price)
        self.findTotalButton.clicked.connect(self.find_total_amount)
        self.calculateBalanceButton.clicked.connect(self.calculate_balance)
        self.calculateDeliveryDateButton.clicked.connect(self.calculate_delivery_date)

    # Function methods would go here as in the previous example

if __name__ == '__main__':
    app = QApplication(sys.argv)
    window = BookPriceFinder()
    window.show()
    sys.exit(app.exec_())
