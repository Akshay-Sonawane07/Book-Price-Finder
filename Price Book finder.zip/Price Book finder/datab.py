import re
import sys
import sqlite3
from PyQt5.QtWidgets import (
    QApplication, QWidget, QLabel, QLineEdit, QPushButton, QVBoxLayout, QMessageBox, QDesktopWidget
)
from PyQt5.QtGui import QFont
from PyQt5.QtCore import Qt
from datetime import datetime, timedelta

class BookPriceFinder(QWidget):
    def __init__(self):
        super().__init__()

        # Window title, icon, and size
        self.setWindowTitle("Book Price Finder with Payment and Delivery Date")
        
        # Get screen size and set window size
        screen = QDesktopWidget().screenGeometry()
        width, height = screen.width(), screen.height()
        self.setGeometry(int(width * 0.1), int(height * 0.1), int(width * 0.8), int(height * 0.8))
        self.setStyleSheet("background-color: #F0F8FF;")
        
        # Layout
        layout = QVBoxLayout()
        layout.setSpacing(20)
        layout.setContentsMargins(30, 30, 30, 30)
        
        # Widgets
        self.titleLabel = QLabel("Book Title:")
        self.titleLabel.setFont(QFont("Verdana", 14))
        self.titleInput = QLineEdit(self)
        self.titleInput.setFont(QFont("Verdana", 14))
        
        self.priceLabel = QLabel("Price (₹):")
        self.priceLabel.setFont(QFont("Verdana", 14))
        self.priceOutput = QLineEdit(self)
        self.priceOutput.setFont(QFont("Verdana", 14))
        self.priceOutput.setReadOnly(True)
        
        self.quantityLabel = QLabel("Quantity:")
        self.quantityLabel.setFont(QFont("Verdana", 14))
        self.quantityInput = QLineEdit(self)
        self.quantityInput.setFont(QFont("Verdana", 14))
        self.quantityInput.setPlaceholderText("Enter quantity")
        
        self.totalAmountLabel = QLabel("Total Amount (₹):")
        self.totalAmountLabel.setFont(QFont("Verdana", 14))
        self.totalAmountOutput = QLineEdit(self)
        self.totalAmountOutput.setFont(QFont("Verdana", 14))
        self.totalAmountOutput.setReadOnly(True)
        
        self.paymentLabel = QLabel("Payment (₹):")
        self.paymentLabel.setFont(QFont("Verdana", 14))
        self.paymentInput = QLineEdit(self)
        self.paymentInput.setFont(QFont("Verdana", 14))
        self.paymentInput.setPlaceholderText("Enter payment amount")
        
        self.balanceLabel = QLabel("Remaining Balance (₹):")
        self.balanceLabel.setFont(QFont("Verdana", 14))
        self.balanceOutput = QLineEdit(self)
        self.balanceOutput.setFont(QFont("Verdana", 14))
        self.balanceOutput.setReadOnly(True)
        
        self.deliveryDateLabel = QLabel("Expected Delivery Date:")
        self.deliveryDateLabel.setFont(QFont("Verdana", 14))
        self.deliveryDateOutput = QLineEdit(self)
        self.deliveryDateOutput.setFont(QFont("Verdana", 14))
        self.deliveryDateOutput.setReadOnly(True)
        
        # Buttons with enhanced styles
        self.findPriceButton = QPushButton("Find Price", self)
        self.findPriceButton.setFont(QFont("Verdana", 14))
        self.findPriceButton.setStyleSheet(
            "background-color: #4CAF50; color: white; padding: 10px; border-radius: 8px;"
        )
        self.findPriceButton.setCursor(Qt.PointingHandCursor)
        
        self.findTotalButton = QPushButton("Find Total Amount", self)
        self.findTotalButton.setFont(QFont("Verdana", 14))
        self.findTotalButton.setStyleSheet(
            "background-color: #2196F3; color: white; padding: 10px; border-radius: 8px;"
        )
        self.findTotalButton.setCursor(Qt.PointingHandCursor)
        
        self.calculateBalanceButton = QPushButton("Calculate Balance", self)
        self.calculateBalanceButton.setFont(QFont("Verdana", 14))
        self.calculateBalanceButton.setStyleSheet(
            "background-color: #FF5722; color: white; padding: 10px; border-radius: 8px;"
        )
        self.calculateBalanceButton.setCursor(Qt.PointingHandCursor)
        
        self.calculateDeliveryDateButton = QPushButton("Calculate Delivery Date", self)
        self.calculateDeliveryDateButton.setFont(QFont("Verdana", 14))
        self.calculateDeliveryDateButton.setStyleSheet(
            "background-color: #9C27B0; color: white; padding: 10px; border-radius: 8px;"
        )
        self.calculateDeliveryDateButton.setCursor(Qt.PointingHandCursor)
        
        # Adding widgets to layout
        layout.addWidget(self.titleLabel)
        layout.addWidget(self.titleInput)
        layout.addWidget(self.priceLabel)
        layout.addWidget(self.priceOutput)
        layout.addWidget(self.quantityLabel)
        layout.addWidget(self.quantityInput)
        layout.addWidget(self.totalAmountLabel)
        layout.addWidget(self.totalAmountOutput)
        layout.addWidget(self.paymentLabel)
        layout.addWidget(self.paymentInput)
        layout.addWidget(self.balanceLabel)
        layout.addWidget(self.balanceOutput)
        layout.addWidget(self.deliveryDateLabel)
        layout.addWidget(self.deliveryDateOutput)
        layout.addWidget(self.findPriceButton)
        layout.addWidget(self.findTotalButton)
        layout.addWidget(self.calculateBalanceButton)
        layout.addWidget(self.calculateDeliveryDateButton)
        
        # Setting layout
        self.setLayout(layout)
        
        # Connecting buttons to functions
        self.findPriceButton.clicked.connect(self.find_price)
        self.findTotalButton.clicked.connect(self.find_total_amount)
        self.calculateBalanceButton.clicked.connect(self.calculate_balance)
        self.calculateDeliveryDateButton.clicked.connect(self.calculate_delivery_date)
    
    def validate_title(self, title):
        return bool(re.match("^[A-Za-z ]+$", title))

    def validate_quantity(self, quantity):
        return quantity.isdigit()

    def validate_payment(self, payment):
        try:
            float(payment)
            return True
        except ValueError:
            return False
    
    def find_price(self):
        title = self.titleInput.text().strip()
        
        if not self.validate_title(title):
            QMessageBox.warning(self, "Input Error", "Book title must contain only alphabets and spaces.")
            return
        
        conn = sqlite3.connect('books.db')
        cursor = conn.cursor()
        
        cursor.execute("SELECT price FROM books WHERE title = ?", (title,))
        result = cursor.fetchone()
        
        if result:
            self.priceOutput.setText(f"₹{result[0]:.2f}")
        else:
            QMessageBox.warning(self, "Not Found", "The book is not found in the database.")
            self.priceOutput.clear()
        
        conn.close()
    
    def find_total_amount(self):
        try:
            price = float(self.priceOutput.text().replace('₹', ''))
            quantity = self.quantityInput.text().strip()
            
            if not self.validate_quantity(quantity):
                raise ValueError("Invalid quantity.")
            
            total = price * int(quantity)
            self.totalAmountOutput.setText(f"₹{total:.2f}")
        except ValueError:
            QMessageBox.warning(self, "Input Error", "Please ensure both price and quantity are valid.")
            self.totalAmountOutput.clear()
    
    def calculate_balance(self):
        try:
            total_amount = float(self.totalAmountOutput.text().replace('₹', ''))
            payment = self.paymentInput.text().strip()
            
            if not self.validate_payment(payment):
                raise ValueError("Invalid payment.")
            
            balance = total_amount - float(payment)
            self.balanceOutput.setText(f"₹{balance:.2f}")
        except ValueError:
            QMessageBox.warning(self, "Input Error", "Please ensure both payment and total amount are valid.")
            self.balanceOutput.clear()
    
    def calculate_delivery_date(self):
        estimated_delivery_days = 5
        current_date = datetime.now()
        delivery_date = current_date + timedelta(days=estimated_delivery_days)
        self.deliveryDateOutput.setText(delivery_date.strftime("%d-%m-%Y"))

if __name__ == '__main__':
    app = QApplication(sys.argv)
    window = BookPriceFinder()
    window.show()
    sys.exit(app.exec_())
